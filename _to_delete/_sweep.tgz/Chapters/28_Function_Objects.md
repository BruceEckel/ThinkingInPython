# Function Objects

A *function object* decouples the choice of function to call from the place that calls it.
That decoupling is the goal of several patterns: *Command*, *Strategy*,
and *Chain of Responsibility*.
The three differ in what they defer.
*Command* defers *what* to do, so the action can be stored and run later.
*Strategy* defers *how* to do a job the caller already has.
*Chain of Responsibility* defers *which* handler takes the job,
trying candidates until one accepts.

In Python a function is already an object.
You can name it, store it in a list, pass it as an argument, and return it.
That makes all three patterns largely unnecessary.
Where *GoF Design Patterns* builds a hierarchy, Python uses a function,
the dissolution described in [The Pattern Concept](21_The_Pattern_Concept.md#when-a-pattern-dissolves).
*Command* and *Strategy* each appear twice below, first as a function,
then as the classic class-based form for contrast.
*Chain of Responsibility* needs only the function form:
its class version is the same idea with the list written as a linked chain.
A closing section keys the chain's handlers by event type instead of by position,
which turns the list into an *event bus*.

## Command: Choosing the Operation at Runtime

A *Command* wraps an action so you can pass it around and run it later.
In Python the action is just a function, and a "macro" is a list of actions:

```python
# command.py
from collections.abc import Callable

def loony() -> None:
    print("You're a loony.")

def new_brain() -> None:
    print("You might even need a new brain.")

def afford() -> None:
    print("I couldn't afford a whole new brain.")

macro: list[Callable[[], None]] = [loony, new_brain, afford]
for command in macro:
    command()
#: You're a loony.
#: You might even need a new brain.
#: I couldn't afford a whole new brain.
```

The classic object form wraps each action in a `Command` subclass with an `execute()` method:

```python
# command_pattern.py
from typing import override

class Command:
    def execute(self) -> None:
        raise NotImplementedError

class Loony(Command):
    @override
    def execute(self) -> None:
        print("You're a loony.")

class NewBrain(Command):
    @override
    def execute(self) -> None:
        print("You might even need a new brain.")

class Afford(Command):
    @override
    def execute(self) -> None:
        print("I couldn't afford a whole new brain.")

# An object that holds commands:
class Macro:
    def __init__(self) -> None:
        self.commands: list[Command] = []
    def add(self, command: Command) -> None:
        self.commands.append(command)
    def run(self) -> None:
        for c in self.commands:
            c.execute()

macro = Macro()
macro.add(Loony())
macro.add(NewBrain())
macro.add(Afford())
macro.run()
#: You're a loony.
#: You might even need a new brain.
#: I couldn't afford a whole new brain.
```

Both do the same thing.
The class version is four classes and a wrapper to say what one list of functions says directly.
*GoF Design Patterns* calls commands "an object-oriented replacement for callbacks."
In Python a callback is just a function, so the replacement is unnecessary.
Use the object form when a command must support extra operations such as undo.
Halfway between the two, a *bound method* is a ready-made command.
`account.deposit` names a function with its instance already attached,
so it drops into a command list alongside plain functions,
carrying its state without any `Command` class.

An object can be callable too.
Give a class `__call__()`
([Decorators](14_Decorators.md#a-stateless-class-decorator))
and its instances carry state and still satisfy `Callable[[], None]`:

```python
# callable_command.py
from collections.abc import Callable
from dataclasses import dataclass

@dataclass(frozen=True)
class Repeat:
    text: str
    times: int
    def __call__(self) -> None:
        for _ in range(self.times):
            print(self.text)

macro: list[Callable[[], None]] = [
    Repeat("You're a loony.", 1),
    Repeat("Say no more.", 2),
]
for command in macro:
    command()
#: You're a loony.
#: Say no more.
#: Say no more.
```

`Repeat` holds configuration and drops into the same list as `loony`,
with no `Command` base class to derive from.
That is the rung the classic form skips.
The `Command` class earns its keep only at the next step,
when the command needs a *second* operation, `undo()`,
which no single callable can express.

Building commands in a loop springs Python's best-known closure trap:

```python
# late_binding.py
from collections.abc import Callable
from functools import partial

commands: list[Callable[[], None]] = [
    lambda: print(f"step {n}") for n in range(3)
]
for command in commands:
    command()  # Every lambda sees the final n
#: step 2
#: step 2
#: step 2

fixed: list[Callable[[], None]] = [
    partial(print, f"step {n}") for n in range(3)
]
for command in fixed:
    command()
#: step 0
#: step 1
#: step 2
```

The two comprehensions look alike and differ in when they read `n`.
A lambda's body runs when the command is called, not when it is created,
and all three lambdas close over the one loop variable,
which holds 2 by the time anything calls them.
The argument to `functools.partial`
([Foundations](40_Functional_Foundations.md#partial-application))
is an ordinary expression, evaluated where it is written,
so each command stores the string built from that iteration's `n`.
Nothing is left to look up later.
The older form `lambda n=n: ...` does the same job with a default argument.
When commands built in a loop all behave like the last one, this is why.

## Strategy: Choosing the Algorithm at Runtime

A *Strategy* is an interchangeable algorithm.
The following examples use three algorithms that find a *root* of a function `f`,
a value where `f(x)` is zero.
Each takes the function and two hints and returns the root,
or `None` when it cannot find one.
Bisection reads the two hints as a bracket,
an interval whose ends straddle the root.
The secant method reads them as two starting points,
and Newton's method averages them into one.
Those two are *open* methods: they need somewhere to start, not a bracket,
which is why the chain below can fall back on them.
All three share one signature, so they are interchangeable:

```python
# algorithms.py
from collections.abc import Callable
from typing import Final

type Fn = Callable[[float], float]
type RootFinder = Callable[[Fn, float, float], float | None]

TOLERANCE: Final[float] = 1e-12
MAX_ITER: Final[int] = 200

def bisection(f: Fn, a: float, b: float) -> float | None:
    if f(a) * f(b) > 0:  # Endpoints must bracket a root
        return None
    for _ in range(MAX_ITER):
        mid = (a + b) / 2
        if abs(f(mid)) < TOLERANCE:
            return mid
        if f(a) * f(mid) <= 0:
            b = mid
        else:
            a = mid
    return None

def secant(f: Fn, a: float, b: float) -> float | None:
    x0, x1 = a, b
    for _ in range(MAX_ITER):
        f0, f1 = f(x0), f(x1)
        if f1 == f0:  # Flat step: cannot continue
            return None
        x2 = x1 - f1 * (x1 - x0) / (f1 - f0)
        if abs(x2 - x1) < TOLERANCE:
            return x2
        x0, x1 = x1, x2
    return None

def newton(f: Fn, a: float, b: float) -> float | None:
    x = (a + b) / 2  # Start between the hints
    h = 1e-7
    for _ in range(MAX_ITER):
        # Approximate the derivative with a central difference:
        slope = (f(x + h) - f(x - h)) / (2 * h)
        if slope == 0:
            return None
        step = f(x) / slope
        x -= step
        if abs(step) < TOLERANCE:
            return x
    return None
```

Because each finder is a function with the same signature,
passing one to `solve()` chooses the strategy,
and the loop below tries each choice in turn:

```python
# strategy.py
from algorithms import Fn, RootFinder, bisection, newton, secant

def solve(f: Fn, a: float, b: float,
          finder: RootFinder) -> float | None:
    return finder(f, a, b)

def f(x: float) -> float:
    return x * x - 2  # Root at the square root of 2

for finder in (bisection, newton, secant):
    root = solve(f, 0.0, 2.0, finder)
    assert root is not None
    print(f"{root:.6f}")
#: 1.414214
#: 1.414214
#: 1.414214
```

Three identical lines is the point:
the caller does not change when the algorithm does.
The algorithms are not equivalent, though,
and the chain below turns the difference between them into a fallback.

The classic form makes each algorithm a class deriving from a common interface,
and adds a "Context" object to hold the current strategy:

```python
# strategy_pattern.py
from typing import override
from algorithms import Fn, bisection, newton, secant

# The strategy interface:
class FindRoot:
    def find(self, f: Fn, a: float, b: float) -> float | None:
        raise NotImplementedError

# Each strategy wraps one algorithm from algorithms.py:
class Bisection(FindRoot):
    @override
    def find(self, f: Fn, a: float, b: float) -> float | None:
        return bisection(f, a, b)

class Newton(FindRoot):
    @override
    def find(self, f: Fn, a: float, b: float) -> float | None:
        return newton(f, a, b)

class Secant(FindRoot):
    @override
    def find(self, f: Fn, a: float, b: float) -> float | None:
        return secant(f, a, b)

# The "Context" controls the strategy:
class RootSolver:
    def __init__(self, strategy: FindRoot) -> None:
        self.strategy = strategy

    def solve(self, f: Fn, a: float, b: float) -> float | None:
        return self.strategy.find(f, a, b)

    def change_algorithm(self, new_algorithm: FindRoot) -> None:
        self.strategy = new_algorithm

def f(x: float) -> float:
    return x * x - 2

solver = RootSolver(Bisection())
for algorithm in (Bisection(), Newton(), Secant()):
    solver.change_algorithm(algorithm)
    root = solver.solve(f, 0.0, 2.0)
    assert root is not None
    print(f"{root:.6f}")
#: 1.414214
#: 1.414214
#: 1.414214
```

Five classes produce the same three lines that one function argument produced.
The Context earns its keep when something has to hold the current algorithm between calls,
which a parameter cannot do.

Python uses strategies-as-functions constantly without calling them a pattern.
The `key` argument to `sorted()`, `min()`, and `max()` is a strategy.
You provide a function that decides how to compare.

When a strategy needs configuration, the next step is not yet a class.
It is a *closure* ([Foundations](40_Functional_Foundations.md#closures)),
a function that manufactures the strategy with the settings baked in:

```python
# configured_strategy.py
from algorithms import Fn, RootFinder

def bisection_within(tolerance: float) -> RootFinder:
    def finder(f: Fn, a: float, b: float) -> float | None:
        if f(a) * f(b) > 0:  # Endpoints must bracket a root
            return None
        while abs(b - a) > tolerance:
            mid = (a + b) / 2
            if f(a) * f(mid) <= 0:
                b = mid
            else:
                a = mid
        return (a + b) / 2
    return finder

def f(x: float) -> float:
    return x * x - 2  # Root at the square root of 2

coarse = bisection_within(0.1)
fine = bisection_within(1e-9)
r1, r2 = coarse(f, 0.0, 2.0), fine(f, 0.0, 2.0)
assert r1 is not None and r2 is not None
print(f"{r1:.6f} {r2:.6f}")
#: 1.406250 1.414214
```

Each call to `bisection_within()` returns a new finder with its tolerance sealed inside.
The coarse strategy stops within a tenth and reports 1.406250.
The fine one agrees with the true root to six places.
Both satisfy `RootFinder`, so either drops into `solve()`,
or into the chain below, unchanged.
`functools.partial` does the same job when a configurable version already exists with the setting as a parameter.
If that setting is a positional argument sitting after the one the caller supplies,
`Placeholder` ([Foundations](40_Functional_Foundations.md#leaving-a-gap-with-placeholder))
fills the gap.
Save the strategy class for an algorithm that carries several related methods or mutable state.
Configuration alone is a closure's job.

## Chain of Responsibility: Choosing the Handler at Runtime

*Chain of Responsibility* tries a sequence of handlers until one succeeds.
*GoF Design Patterns* implements the chain as a linked structure,
each handler holding a reference to the next and deciding whether to pass the request along.
In Python the chain is a list of functions,
and the loop that walks it makes that decision in one place.
Bisection needs the interval to bracket a root.
The open methods do not:

```python
# chain.py
from algorithms import Fn, RootFinder, bisection, newton, secant

def solve(f: Fn, a: float, b: float,
          chain: list[RootFinder]) -> float | None:
    for finder in chain:
        root = finder(f, a, b)
        if root is not None:
            return root
    return None

def f(x: float) -> float:
    return x * x - 2  # Root at the square root of 2

chain: list[RootFinder] = [bisection, secant, newton]
# [0, 2] brackets the root, so bisection succeeds first:
r1 = solve(f, 0.0, 2.0, chain)
print(f"{r1:.6f}" if r1 is not None else "no root")
#: 1.414214
# [1.0, 1.3] does not bracket it; bisection fails, secant finds it:
print(bisection(f, 1.0, 1.3))
#: None
r2 = solve(f, 1.0, 1.3, chain)
print(f"{r2:.6f}" if r2 is not None else "no root")
#: 1.414214
```

Each handler is a *Strategy* function, the chain is the list,
and success is a non-`None` return.
The test is `root is not None`, not `if root`.
A function with a root at zero returns `0.0`, which is falsy,
so a truthiness test would throw away a correct answer and hand the problem to the next finder.
Any sentinel-versus-value check on a numeric result has this hazard.

Adding, removing, or reordering handlers means editing a list.
The second call shows the fall-through.
The interval `[1.0, 1.3]` does not straddle the root,
so bisection declines by returning `None` and the chain moves on to a method that needs no bracket.

These tests confirm that the first finder that converges wins,
a later finder rescues one that fails, an empty chain returns `None`,
and a chain where every finder fails returns `None` too:

```python
# test_chain.py
from algorithms import bisection, newton, secant
from chain import solve

def f(x: float) -> float:
    return x * x - 2  # Root at the square root of 2

def test_first_successful_finder_wins() -> None:
    root = solve(f, 0.0, 2.0, [bisection, secant, newton])
    assert root is not None
    assert abs(root - 2 ** 0.5) < 1e-6

def test_chain_falls_through_to_a_later_method() -> None:
    # [1.0, 1.3] does not bracket the root: bisection fails
    root = solve(f, 1.0, 1.3, [bisection, secant, newton])
    assert root is not None
    assert abs(root - 2 ** 0.5) < 1e-6

def test_empty_chain_returns_none() -> None:
    assert solve(f, 0.0, 2.0, []) is None

def test_all_fail_returns_none() -> None:
    def g(x: float) -> float:
        return x * x + 1  # No real root
    assert solve(g, 0.0, 2.0, [bisection]) is None
```

## An Event Bus: Handlers Keyed by Type

Chain of Responsibility kept its handlers in a list and tried them in order.
If you key that structure by type instead of by position,
you have an *event bus*.
This is a `dict` from each event type to the functions that care about it.
The events are values,
written as [frozen data classes](12_Data_Classes_as_Types.md#immutability).
Publishing an event looks up its type and calls every handler registered for it.
The handlers are ordinary functions,
so there is no base class to inherit from and no registration ceremony.
`Handler` below names their signature, not an interface:

```python
# event_bus.py
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

type Handler[E] = Callable[[E], None]

@dataclass(frozen=True)
class Deposit:
    amount: int

@dataclass(frozen=True)
class Withdraw:
    amount: int

@dataclass(frozen=True)
class Closed:
    reason: str

class EventBus:
    def __init__(self) -> None:
        self._handlers: defaultdict[
            type, list[Handler[Any]]
        ] = defaultdict(list)

    def subscribe[E](self, event_type: type[E],
                     handler: Handler[E]) -> None:
        self._handlers[event_type].append(handler)

    def publish(self, event: object) -> None:
        for handler in self._handlers.get(type(event), []):
            handler(event)

def on_deposit(event: Deposit) -> None:
    print(f"+ deposit {event.amount}")

def audit(event: Deposit) -> None:
    print(f"  audit: a deposit of {event.amount}")

def on_withdraw(event: Withdraw) -> None:
    print(f"- withdraw {event.amount}")

bus = EventBus()
bus.subscribe(Deposit, on_deposit)
bus.subscribe(Deposit, audit)  # Two handlers for one event type
bus.subscribe(Withdraw, on_withdraw)

bus.publish(Deposit(100))
#: + deposit 100
#:   audit: a deposit of 100
bus.publish(Withdraw(30))
#: - withdraw 30
bus.publish(Closed("inactivity"))  # No handler: nothing happens
```

`subscribe` is generic on the event type `E`, which appears in both parameters,
so the checker must find one `E` that satisfies the event type and the handler together.
No such `E` exists for `subscribe(Deposit, on_withdraw)` and it is a type error.
The safety check happens once, at registration.
The stored `defaultdict`, though,
mixes handlers for every event type in one structure.
Its lists cannot name a single event class,
so the element type erases the parameter to `Handler[Any]`.

`subscribe` indexes `self._handlers` directly,
letting the `defaultdict` build each event type's list on first use.
`publish` still calls `.get(type(event), [])` instead of indexing.
Indexing on a read inserts an empty list as a side effect,
leaving a stray entry behind for every published event type that happens to have no subscriber,
such as `Closed`.

The lookup uses `type(event)`, which matches the class and no ancestor.
A subclass of `Deposit` published to this bus finds no handler and vanishes as quietly as `Closed` does.
Walking `type(event).__mro__` and calling every handler along it gives subclass events their parent's handlers,
at the cost of an event type no longer naming its audience by itself.

The tests confirm that publishing calls every handler registered for a type,
a handler hears only its own event type,
and an event with no handler is a quiet no-op:

```python
# test_event_bus.py
from event_bus import Closed, Deposit, EventBus, Withdraw

def test_every_handler_for_the_type_is_called() -> None:
    seen: list[str] = []
    bus = EventBus()
    bus.subscribe(Deposit, lambda e: seen.append(f"a{e.amount}"))
    bus.subscribe(Deposit, lambda e: seen.append(f"b{e.amount}"))
    bus.publish(Deposit(5))
    assert seen == ["a5", "b5"]

def test_only_the_matching_type_is_called() -> None:
    calls: list[str] = []
    bus = EventBus()
    bus.subscribe(Deposit, lambda e: calls.append("deposit"))
    bus.subscribe(Withdraw, lambda e: calls.append("withdraw"))
    bus.publish(Withdraw(1))
    assert calls == ["withdraw"]

def test_no_handler_is_a_noop() -> None:
    EventBus().publish(Closed("done"))  # Must not raise
```

This is the [Observer](30_Observer.md#the-pythonic-observer-a-list-of-callables)
with one shared subject: instead of every observable holding its own list,
one bus holds them all and the event type picks the audience.
Here a type may have many handlers.
If you instead want a single handler per type,
chosen by the argument's type and open to new types without editing a central function,
that is `functools.singledispatch`,
used by [Visitor](33_Visitor.md#the-pythonic-visitor-singledispatch)
and [Pattern Refactoring](37_Pattern_Refactoring.md#adding-operations-visitor-and-why-python-skips-it).

## Exercises

1.  Add an "undo" capability to `command.py`.
    What do the commands need to become, and is a function still enough,
    or do you now want an object?
2.  Rewrite `chain.py` so each handler also reports why it failed,
    and the solver prints every attempt before returning the winner.
3.  Use `sorted()` with a `key` function to sort a list of `(name, score)` tuples by score,
    then by name.
    Explain why `key` is the *Strategy* pattern.
4.  Following `bisection_within()`,
    add a `tolerance` parameter to `newton()` in `algorithms.py` and build a configured strategy from it two ways:
    with a closure, and with `functools.partial`.
    Confirm both drop into `chain.py`'s `solve()` with no change to `solve()`.
5.  `EventBus.publish()` looks up `type(event)`,
    so a subclass of `Deposit` finds no handler.
    Change `publish()` to walk `type(event).__mro__` and call every handler registered along it,
    parents last.
    Then add `unsubscribe()`.
    Which of the two changes can break an existing caller, and why?
